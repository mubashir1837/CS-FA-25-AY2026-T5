# CS 2205: Web Programming 1
## Assignment Activity Unit 5


---

### Introduction
The objective of this assignment is to develop a dynamic To-Do list application using HTML, CSS, and JavaScript. The application demonstrates the core concepts of Document Object Model (DOM) manipulation and Event Delegation. 

Users can:
1. Add new tasks.
2. Edit existing tasks using a native browser dialog box.
3. Remove tasks.
4. Mark tasks as complete or incomplete via a checkbox.

By using **event delegation** on the parent unordered list (`<ul>`), the application handles user interactions efficiently without needing to attach individual event listeners to every newly created button or checkbox.

---

### 1. HTML, CSS, and JavaScript Code

Below is the complete source code for the To-Do List application. I have included detailed comments to explain the intent and logic behind the code, emphasizing how event delegation and DOM manipulation are utilized.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <style>
        /* Basic styling to match the provided images */
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        
        .container {
            max-width: 600px;
        }
        
        h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        
        .input-area {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        #new-task {
            flex: 1;
            padding: 8px 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        
        #add-task-btn {
            padding: 8px 16px;
            font-size: 16px;
            background-color: #4CAF50; /* Green button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        #add-task-btn:hover {
            background-color: #45a049;
        }
        
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        li {
            margin-bottom: 15px;
        }
        
        /* Layout for the checkbox and task text */
        .task-row {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }
        
        .task-checkbox {
            margin-right: 10px;
            cursor: pointer;
        }
        
        .task-text {
            font-size: 18px;
        }
        
        /* Style applied when the checkbox is checked */
        .completed {
            text-decoration: line-through;
            color: #888;
        }
        
        /* Layout for the Edit and Remove buttons */
        .button-row {
            margin-left: 28px; /* Aligns buttons with the text, accounting for checkbox width */
        }
        
        .edit-btn, .remove-btn {
            padding: 6px 12px;
            font-size: 14px;
            background-color: #f44336; /* Red buttons */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }
        
        .edit-btn:hover, .remove-btn:hover {
            background-color: #e53935;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>To-Do List</h1>
    <div class="input-area">
        <input type="text" id="new-task" placeholder="Enter new task">
        <button id="add-task-btn">Add Task</button>
    </div>
    <ul id="task-list">
        <!-- Tasks will be appended here dynamically by JavaScript -->
    </ul>
</div>

<script>
    // Select DOM elements
    const taskInput = document.getElementById('new-task');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');

    // Event listener to add task when button is clicked
    addTaskBtn.addEventListener('click', addTask);
    
    // Event listener to add task when 'Enter' key is pressed in the input field
    taskInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addTask();
        }
    });

    // Function to handle adding a new task
    function addTask() {
        const taskText = taskInput.value.trim();
        
        // Prevent adding empty tasks
        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        // Create the list item element
        const li = document.createElement('li');
        
        // Set the inner HTML. 
        // We structure it with a row for text/checkbox and a row for buttons to match the image.
        li.innerHTML = `
            <div class="task-row">
                <input type="checkbox" class="task-checkbox">
                <span class="task-text">${taskText}</span>
            </div>
            <div class="button-row">
                <button class="edit-btn">Edit</button>
                <button class="remove-btn">Remove</button>
            </div>
        `;

        // Append the new task to the unordered list
        taskList.appendChild(li);
        
        // Clear the input field for the next entry
        taskInput.value = ''; 
    }

    // EVENT DELEGATION
    // We attach a single event listener to the parent <ul> to handle clicks on any child elements.
    // This is more efficient than adding individual listeners to every single button.
    taskList.addEventListener('click', function(e) {
        
        // 1. Handle marking task as complete/incomplete
        if (e.target.classList.contains('task-checkbox')) {
            // Find the adjacent span containing the text
            const taskSpan = e.target.nextElementSibling;
            
            if (e.target.checked) {
                taskSpan.classList.add('completed'); // Adds strike-through styling
            } else {
                taskSpan.classList.remove('completed'); // Removes strike-through styling
            }
        }
        
        // 2. Handle removing a task
        else if (e.target.classList.contains('remove-btn')) {
            // Find the closest parent <li> and remove it from the DOM
            const li = e.target.closest('li');
            li.remove();
        }
        
        // 3. Handle editing a task
        else if (e.target.classList.contains('edit-btn')) {
            // Find the text span for this specific task
            const li = e.target.closest('li');
            const taskSpan = li.querySelector('.task-text');
            const currentText = taskSpan.textContent;
            
            // Open the standard browser prompt dialog (as shown in the provided screenshot)
            const updatedText = prompt('Edit task:', currentText);
            
            // If the user clicked 'OK' (not null) and didn't leave it empty, update the DOM
            if (updatedText !== null && updatedText.trim() !== '') {
                taskSpan.textContent = updatedText.trim();
            }
        }
    });
</script>

</body>
</html>
```

---

### 2. Output Screenshots

**Main Interface:**
This screenshot displays the main interface of the to-do list. It shows dynamically added tasks, with one marked as complete (indicated by the strike-through text and grey color).

![Main Interface](./s1.png)

**Edit Task Dialog:**
This screenshot demonstrates the editing functionality. When the "Edit" button is clicked, a native browser prompt appears, allowing the user to update the task's text efficiently.

![Edit Dialog](./s2.png)

---

### Conclusion
This assignment successfully implements a to-do list using standard HTML, CSS, and vanilla JavaScript. By leveraging event delegation on the task list container, the application minimizes event listener overhead, resulting in a cleaner and more performant approach to handling dynamic DOM elements.

---

### References

* Codecademy. (n.d.). *DOM Events with JavaScript*. Retrieved from https://www.codecademy.com/learn/fscp-building-interactive-websites-with-javascript/modules/fecp-dom-events-with-javascript/cheatsheet
* Codecademy. (n.d.). *JavaScript and the DOM*. Retrieved from https://www.codecademy.com/learn/fscp-building-interactive-websites-with-javascript/modules/fecp-javascript-and-the-dom/cheatsheet
* Jack, A. (2021, June 21). *The DOM in 4 minutes* [Video]. YouTube. 
* Jeansoulin, R. (2018). *JavaScript and open data*. John Wiley & Sons, Incorporated.
* Labrecque, J., Love, J., Rosenbaum, D., Turner, N., Mehla, G., L., H. A., Sloot, F., & Kirkbride, P. (2019). *The JavaScript workshop: Learn to develop interactive web applications with clean and maintainable JavaScript code*. Packt Publishing, Limited.
* McGrath, M. (2020). *JavaScript in easy steps* (6th ed.). In Easy Steps Limited.
* MDN Web Docs. (2023, December 17). *Document Object Model (DOM)*. https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model
* Shute, Z. (2019). *Advanced JavaScript: Speed up web development with the powerful features and benefits of JavaScript*. Packt Publishing, Limited.
* Web Dev Simplified. (2020, December 9). *Learn DOM Manipulation in 18 Minutes* [Video]. YouTube.
* Web Dev Simplified. (2020, December 12). *Learn JavaScript Event Listeners in 18 Minutes* [Video]. YouTube.
