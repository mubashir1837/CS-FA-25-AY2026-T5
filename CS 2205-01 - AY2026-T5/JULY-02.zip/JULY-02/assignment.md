# Unit 3 Assignment: HTML Forms

**Course:** CS 2205 - Web Programming 1  
**Date:** July 2026  

---

## 1. Code Intent and Explanations

*(Note for student: The rubric asks for comments explaining the code intent. Since the comments were removed from the HTML file, you can include this section in your Word document to fulfill that requirement.)*

The primary intent of this HTML code is to create a robust, accessible, and user-friendly contact form that meets all assignment requirements, including client-side validation and dual-method submission (GET and POST).

*   **Form Structure & GET Preview (`<form action="" method="GET">`)**: The form defaults to the `GET` method. This is implemented specifically to satisfy the preview requirement. By submitting via GET, the form data is temporarily appended to the URL. A JavaScript function then reads these URL parameters to display the preview box seamlessly on the same page, avoiding the need for a backend server.
*   **Client-Side Validation**: 
    *   The `required` attribute ensures the user cannot submit an empty form. 
    *   `type="email"` utilizes HTML5's native validation to guarantee the email input is formatted correctly. 
    *   The `pattern="[0-9]{10}"` attribute on the phone number field strictly enforces a 10-digit format using a regular expression, preventing invalid data entry.
*   **POST Submission Override (`formmethod="POST"`)**: The "Submit" button uses the `formmethod="POST"` attribute. This cleverly overrides the default GET method of the form when the user actually submits, fulfilling the requirement to submit the data using POST to a server (using a public testing endpoint).
*   **JavaScript Preview Logic**: The JavaScript `window.onload` function listens for the page to load, checks if the URL contains `action=preview`, and if so, extracts the submitted GET parameters. It then populates the hidden preview section and alters its CSS to make it visible.

---

## 2. HTML Code

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f7f6;
            color: #333;
        }

        .form-container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 20px 30px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .radio-group label {
            display: inline;
            font-weight: normal;
            margin-right: 15px;
        }

        .preview-section {
            background-color: #e9ecef;
            padding: 15px;
            border: 1px solid #c8cbcf;
            margin-top: 20px;
            border-radius: 8px;
            display: none;
        }

        button {
            padding: 10px 20px;
            margin-right: 10px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            color: white;
            font-weight: bold;
        }

        .btn-preview {
            background-color: #17a2b8;
        }

        .btn-preview:hover {
            background-color: #138496;
        }

        .btn-submit {
            background-color: #28a745;
        }

        .btn-submit:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Contact Us</h2>
    
    <form id="contactForm" action="" method="GET">
        
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" title="Please enter exactly 10 digits (e.g., 1234567890)" required>
        </div>

        <div class="form-group">
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
        </div>

        <div class="form-group radio-group">
            <label>Preferred Contact Method:</label><br>
            <input type="radio" id="contactEmail" name="contactMethod" value="Email" required>
            <label for="contactEmail">Email</label>
            
            <input type="radio" id="contactPhone" name="contactMethod" value="Phone">
            <label for="contactPhone">Phone</label>
            
            <input type="radio" id="contactBoth" name="contactMethod" value="Both">
            <label for="contactBoth">Both</label>
        </div>

        <div class="form-group">
            <label for="inquiryType">Inquiry Type:</label>
            <select id="inquiryType" name="inquiryType" required>
                <option value="">Select an option...</option>
                <option value="General Inquiry">General Inquiry</option>
                <option value="Support Request">Support Request</option>
                <option value="Feedback">Feedback</option>
            </select>
        </div>

        <button type="submit" name="action" value="preview" class="btn-preview">Preview</button>
        <button type="submit" name="action" value="submit" formmethod="POST" formaction="https://httpbin.org/post" class="btn-submit">Submit</button>
    </form>
</div>

<div class="form-container preview-section" id="previewSection">
    <h3>Preview of Entered Data</h3>
    <p><strong>Name:</strong> <span id="prevName"></span></p>
    <p><strong>Email:</strong> <span id="prevEmail"></span></p>
    <p><strong>Phone:</strong> <span id="prevPhone"></span></p>
    <p><strong>Message:</strong> <span id="prevMessage"></span></p>
    <p><strong>Contact Method:</strong> <span id="prevContact"></span></p>
    <p><strong>Inquiry Type:</strong> <span id="prevInquiry"></span></p>
</div>

<script>
    window.onload = function() {
        const urlParams = new URLSearchParams(window.location.search);
        
        if (urlParams.get('action') === 'preview') {
            const name = urlParams.get('name');
            const email = urlParams.get('email');
            const phone = urlParams.get('phone');
            const message = urlParams.get('message');
            const contactMethod = urlParams.get('contactMethod');
            const inquiryType = urlParams.get('inquiryType');

            document.getElementById('prevName').innerText = name;
            document.getElementById('prevEmail').innerText = email;
            document.getElementById('prevPhone').innerText = phone;
            document.getElementById('prevMessage').innerText = message;
            document.getElementById('prevContact').innerText = contactMethod;
            document.getElementById('prevInquiry').innerText = inquiryType;

            document.getElementById('previewSection').style.display = 'block';

            document.getElementById('name').value = name;
            document.getElementById('email').value = email;
            document.getElementById('phone').value = phone;
            document.getElementById('message').value = message;
            document.getElementById('inquiryType').value = inquiryType;
            if (contactMethod) {
                const checkedRadio = document.querySelector(`input[name="contactMethod"][value="${contactMethod}"]`);
                if(checkedRadio) checkedRadio.checked = true;
            }
        }
    };
</script>

</body>
</html>
```

---

## 3. Screenshots

*Instruction: Replace the bracketed text below with the actual screenshots taken from your computer.*

### Screenshot 1: Form Layout
[Insert screenshot of the empty form layout here]

### Screenshot 2: Client-Side Form Validation Error
[Insert screenshot showing an HTML5 validation error, e.g., missing email '@' or typing letters in the phone number box, then clicking submit]

### Screenshot 3: Form Preview (GET Method)
[Insert screenshot showing the "Preview of Entered Data" box populated after filling out the form and clicking 'Preview']

### Screenshot 4: POST Submission Success
[Insert screenshot of the httpbin.org page showing the JSON response after clicking 'Submit']
